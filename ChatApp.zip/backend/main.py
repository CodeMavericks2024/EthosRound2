from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime, timedelta
import jwt
from cryptography.fernet import Fernet

app = FastAPI()

# Database setup
SQLALCHEMY_DATABASE_URL = "postgresql://user:password@localhost/dbname"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# JWT setup
SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Encryption setup
ENCRYPTION_KEY = Fernet.generate_key()
fernet = Fernet(ENCRYPTION_KEY)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    hashed_password = Column(String)

class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True, index=True)
    sender_id = Column(Integer)
    receiver_id = Column(Integer)
    content = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)

Base.metadata.create_all(bind=engine)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/register")
async def register(username: str, password: str, db = Depends(get_db)):
    # Implement user registration logic
    pass

@app.post("/login")
async def login(username: str, password: str, db = Depends(get_db)):
    # Implement login logic and return JWT token
    pass

@app.post("/send_message")
async def send_message(receiver_id: int, content: str, expiration_time: int = 0, db = Depends(get_db), current_user: User = Depends(oauth2_scheme)):
    # Implement message sending logic with encryption and expiration
    encrypted_content = fernet.encrypt(content.encode())
    expires_at = datetime.utcnow() + timedelta(minutes=expiration_time) if expiration_time > 0 else None
    new_message = Message(sender_id=current_user.id, receiver_id=receiver_id, content=encrypted_content, expires_at=expires_at)
    db.add(new_message)
    db.commit()
    return {"message": "Message sent successfully"}

@app.get("/messages")
async def get_messages(db = Depends(get_db), current_user: User = Depends(oauth2_scheme)):
    # Implement message retrieval logic with decryption and expiration check
    messages = db.query(Message).filter(Message.receiver_id == current_user.id).all()
    current_time = datetime.utcnow()
    decrypted_messages = []
    for message in messages:
        if message.expires_at is None or message.expires_at > current_time:
            decrypted_content = fernet.decrypt(message.content).decode()
            decrypted_messages.append({
                "id": message.id,
                "sender_id": message.sender_id,
                "content": decrypted_content,
                "created_at": message.created_at,
                "expires_at": message.expires_at
            })
    return decrypted_messages

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)