from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from redis import Redis

# Database connection
engine = create_engine('postgresql://user:password@localhost/dbname')
Session = sessionmaker(bind=engine)

# Redis connection
redis_client = Redis(host='localhost', port=6379, db=0)

def optimize_queries():
    session = Session()
    
    # Add indexes to frequently queried columns
    session.execute(text('CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages (sender_id)'))
    session.execute(text('CREATE INDEX IF NOT EXISTS idx_messages_receiver_id ON messages (receiver_id)'))
    session.execute(text('CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages (created_at)'))
    
    # Analyze tables for query optimization
    session.execute(text('ANALYZE'))
    
    session.commit()
    session.close()

def cache_user_data(user_id, user_data, expiration=3600):
    redis_client.setex(f'user:{user_id}', expiration, user_data)

def get_cached_user_data(user_id):
    return redis_client.get(f'user:{user_id}')

def cache_message(message_id, message_data, expiration=3600):
    redis_client.setex(f'message:{message_id}', expiration, message_data)

def get_cached_message(message_id):
    return redis_client.get(f'message:{message_id}')

# Example usage in your API endpoints
from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session

app = FastAPI()

def get_db():
    db = Session()
    try:
        yield db
    finally:
        db.close()

@app.get("/users/{user_id}")
async def get_user(user_id: int, db: Session = Depends(get_db)):
    cached_user = get_cached_user_data(user_id)
    if cached_user:
        return cached_user
    
    user = db.query(User).filter(User.id == user_id).first()
    if user:
        cache_user_data(user_id, user.to_dict())
    return user

@app.get("/messages/{message_id}")
async def get_message(message_id: int, db: Session = Depends(get_db)):
    cached_message = get_cached_message(message_id)
    if cached_message:
        return cached_message
    
    message = db.query(Message).filter(Message.id == message_id).first()
    if message:
        cache_message(message_id, message.to_dict())
    return message