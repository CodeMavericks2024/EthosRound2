from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
import time
from collections import defaultdict

class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, limit=100, window=60):
        super().__init__(app)
        self.limit = limit
        self.window = window
        self.requests = defaultdict(list)

    async def dispatch(self, request: Request, call_next):
        client_ip = request.client.host
        now = time.time()
        
        # Remove old requests
        self.requests[client_ip] = [req_time for req_time in self.requests[client_ip] if now - req_time < self.window]
        
        # Check if limit is exceeded
        if len(self.requests[client_ip]) >= self.limit:
            return JSONResponse(status_code=429, content={"detail": "Too many requests"})
        
        # Add current request
        self.requests[client_ip].append(now)
        
        response = await call_next(request)
        return response

# In your main.py
from middleware.rateLimiter import RateLimitMiddleware

app.add_middleware(RateLimitMiddleware, limit=100, window=60)