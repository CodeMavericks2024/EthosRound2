import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Keycloak from 'keycloak-js';
import Login from './components/Login';
import Chat from './components/Chat';
import Profile from './components/Profile';
import Settings from './components/Settings';

const App: React.FC = () => {
  const [keycloak, setKeycloak] = useState<Keycloak | null>(null);
  const { t } = useTranslation();

  useEffect(() => {
    const initKeycloak = async () => {
      const keycloakInstance = new Keycloak({
        url: 'YOUR_KEYCLOAK_URL',
        realm: 'YOUR_REALM',
        clientId: 'YOUR_CLIENT_ID'
      });

      try {
        const authenticated = await keycloakInstance.init({ onLoad: 'check-sso' });
        if (authenticated) {
          setKeycloak(keycloakInstance);
        } else {
          console.log('User is not authenticated');
        }
      } catch (error) {
        console.error('Failed to initialize Keycloak:', error);
      }
    };

    initKeycloak();
  }, []);

  if (!keycloak) {
    return <div>{t('loading')}</div>;
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Switch>
          <Route exact path="/" component={keycloak.authenticated ? Chat : Login} />
          <Route path="/profile" component={Profile} />
          <Route path="/settings" component={Settings} />
        </Switch>
      </div>
    </Router>
  );
};

export default App;