import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import Login from '../components/Login';

test('renders login form', () => {
  const { getByPlaceholderText, getByText } = render(<Login />);
  
  expect(getByPlaceholderText('Username')).toBeInTheDocument();
  expect(getByPlaceholderText('Password')).toBeInTheDocument();
  expect(getByText('Login')).toBeInTheDocument();
});

test('submits form with username and password', async () => {
  const { getByPlaceholderText, getByText } = render(<Login />);
  
  fireEvent.change(getByPlaceholderText('Username'), { target: { value: 'testuser' } });
  fireEvent.change(getByPlaceholderText('Password'), { target: { value: 'password123' } });
  
  fireEvent.click(getByText('Login'));
  
  await waitFor(() => {
    expect(getByText('OTP')).toBeInTheDocument();
  });
});