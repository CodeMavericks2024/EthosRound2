import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, Button, StyleSheet } from 'react-native';
import { useSocket } from '../hooks/useSocket';

const GroupChat: React.FC<{ groupId: string }> = ({ groupId }) => {
  const [messages, setMessages] = useState<Array<{ id: string; text: string; sender: string }>>([]);
  const [inputMessage, setInputMessage] = useState('');
  const socket = useSocket();

  useEffect(() => {
    if (socket) {
      socket.emit('joinGroup', groupId);
      socket.on('groupMessage', (message) => {
        setMessages((prevMessages) => [...prevMessages, message]);
      });
    }

    return () => {
      if (socket) {
        socket.emit('leaveGroup', groupId);
        socket.off('groupMessage');
      }
    };
  }, [socket, groupId]);

  const sendMessage = () => {
    if (inputMessage && socket) {
      socket.emit('sendGroupMessage', { groupId, message: inputMessage });
      setInputMessage('');
    }
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={messages}
        renderItem={({ item }) => (
          <View style={styles.messageContainer}>
            <Text style={styles.sender}>{item.sender}:</Text>
            <Text style={styles.messageText}>{item.text}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id}
      />
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={inputMessage}
          onChangeText={setInputMessage}
          placeholder="Type a message..."
        />
        <Button title="Send" onPress={sendMessage} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  messageContainer: {
    marginBottom: 8,
  },
  sender: {
    fontWeight: 'bold',
  },
  messageText: {
    fontSize: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    marginTop: 16,
  },
  input: {
    flex: 1,
    borderColor: 'gray',
    borderWidth: 1,
    marginRight: 8,
    paddingHorizontal: 8,
  },
});

export default GroupChat;