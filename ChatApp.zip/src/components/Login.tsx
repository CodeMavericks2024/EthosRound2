import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { User, Lock } from 'lucide-react';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [showOtp, setShowOtp] = useState(false);
  const { t } = useTranslation();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    // Implement login logic here
    // If first-time login, show OTP field
    setShowOtp(true);
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Implement OTP verification logic here
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="px-8 py-6 mt-4 text-left bg-white shadow-lg">
        <h3 className="text-2xl font-bold text-center">{t('login.title')}</h3>
        <form onSubmit={showOtp ? handleOtpSubmit : handleLogin}>
          {!showOtp ? (
            <>
              <div className="mt-4">
                <div className="flex items-center">
                  <User className="mr-2" />
                  <input
                    type="text"
                    placeholder={t('login.username')}
                    className="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="mt-4">
                <div className="flex items-center">
                  <Lock className="mr-2" />
                  <input
                    type="password"
                    placeholder={t('login.password')}
                    className="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
              </div>
            </>
          ) : (
            <div className="mt-4">
              <input
                type="text"
                placeholder={t('login.otp')}
                className="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                required
              />
            </div>
          )}
          <div className="flex items-baseline justify-between">
            <button className="px-6 py-2 mt-4 text-white bg-blue-600 rounded-lg hover:bg-blue-900">
              {showOtp ? t('login.verifyOtp') : t('login.login')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;