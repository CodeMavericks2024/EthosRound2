import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import io from 'socket.io-client';
import Peer from 'simple-peer';
import { Send, Phone, Video, Image, Clock } from 'lucide-react';

const Chat: React.FC = () => {
  const [messages, setMessages] = useState<Array<{ text: string; sender: string }>>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [expirationTime, setExpirationTime] = useState(0);
  const [peer, setPeer] = useState<Peer.Instance | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const socketRef = useRef<SocketIOClient.Socket | null>(null);
  const { t } = useTranslation();

  useEffect(() => {
    socketRef.current = io('YOUR_SOCKET_SERVER_URL');

    socketRef.current.on('message', (message: { text: string; sender: string }) => {
      setMessages((prevMessages) => [...prevMessages, message]);
    });

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, []);

  const sendMessage = () => {
    if (inputMessage && socketRef.current) {
      socketRef.current.emit('message', { text: inputMessage, sender: 'me' });
      setMessages((prevMessages) => [...prevMessages, { text: inputMessage, sender: 'me' }]);
      setInputMessage('');
    }
  };

  const startCall = async (video: boolean) => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video, audio: true });
      setStream(mediaStream);

      const newPeer = new Peer({ initiator: true, trickle: false, stream: mediaStream });
      setPeer(newPeer);

      newPeer.on('signal', (data) => {
        // Send signaling data to the other peer
        if (socketRef.current) {
          socketRef.current.emit('call-user', { signalData: data, from: socketRef.current.id });
        }
      });

      newPeer.on('stream', (remoteStream) => {
        // Display the remote stream
        const remoteVideo = document.getElementById('remoteVideo') as HTMLVideoElement;
        if (remoteVideo) {
          remoteVideo.srcObject = remoteStream;
        }
      });
    } catch (error) {
      console.error('Error starting call:', error);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <div className="flex-1 overflow-y-auto p-4">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`mb-4 ${
              message.sender === 'me' ? 'text-right' : 'text-left'
            }`}
          >
            <span
              className={`inline-block p-2 rounded-lg ${
                message.sender === 'me' ? 'bg-blue-500 text-white' : 'bg-gray-300'
              }`}
            >
              {message.text}
            </span>
          </div>
        ))}
      </div>
      <div className="p-4 bg-white">
        <div className="flex items-center mb-2">
          <input
            type="number"
            placeholder={t('chat.expirationTime')}
            className="w-24 px-2 py-1 mr-2 border rounded"
            value={expirationTime}
            onChange={(e) => setExpirationTime(parseInt(e.target.value))}
          />
          <Clock className="text-gray-500" />
        </div>
        <div className="flex">
          <input
            type="text"
            placeholder={t('chat.typeMessage')}
            className="flex-1 px-4 py-2 mr-2 border rounded"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
          />
          <button
            onClick={sendMessage}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            <Send />
          </button>
          <button
            onClick={() => startCall(false)}
            className="ml-2 px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
          >
            <Phone />
          </button>
          <button
            onClick={() => startCall(true)}
            className="ml-2 px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-600"
          >
            <Video />
          </button>
          <label className="ml-2 px-4 py-2 bg-orange-500 text-white rounded hover:bg-orange-600 cursor-pointer">
            <Image />
            <input type="file" className="hidden" onChange={() => {/* Handle file upload */}} />
          </label>
        </div>
      </div>
      <video id="remoteVideo" autoPlay playsInline className="hidden" />
    </div>
  );
};

export default Chat;