import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, Button, StyleSheet } from 'react-native';
import { useSocket } from '../hooks/useSocket';

const MessageThread: React.FC<{ parentMessageId: string }> = ({ parentMessageId }) => {
  const [replies, setReplies] = useState<Array<{ id: string; text: string; sender: string }>>([]);
  const [inputReply, setInputReply] = useState('');
  const socket = useSocket();

  useEffect(() => {
    if (socket) {
      socket.emit('joinThread', parentMessageId);
      socket.on('threadReply', (reply) => {
        setReplies((prevReplies) => [...prevReplies, reply]);
      });
    }

    return () => {
      if (socket) {
        socket.emit('leaveThread', parentMessageId);
        socket.off('threadReply');
      }
    };
  }, [socket, parentMessageId]);

  const sendReply = () => {
    if (inputReply && socket) {
      socket.emit('sendThreadReply', { parentMessageId, reply: inputReply });
      setInputReply('');
    }
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={replies}
        renderItem={({ item }) => (
          <View style={styles.replyContainer}>
            <Text style={styles.sender}>{item.sender}:</Text>
            <Text style={styles.replyText}>{item.text}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id}
      />
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={inputReply}
          onChangeText={setInputReply}
          placeholder="Type a reply..."
        />
        <Button title="Reply" onPress={sendReply} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  replyContainer: {
    marginBottom: 8,
  },
  sender: {
    fontWeight: 'bold',
  },
  replyText: {
    fontSize: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    marginTop: 16,
  },
  input: {
    flex: 1,
    borderColor: 'gray',
    borderWidth: 1,
    marginRight: 8,
    paddingHorizontal: 8,
  },
});

export default MessageThread;