import analytics from '@react-native-firebase/analytics';

export async function logEvent(eventName: string, params?: object) {
  try {
    await analytics().logEvent(eventName, params);
    console.log(`Logged event: ${eventName}`);
  } catch (error) {
    console.error('Error logging event:', error);
  }
}

export async function setUserProperties(properties: object) {
  try {
    await analytics().setUserProperties(properties);
    console.log('Set user properties');
  } catch (error) {
    console.error('Error setting user properties:', error);
  }
}

export async function setUserId(userId: string) {
  try {
    await analytics().setUserId(userId);
    console.log('Set user ID');
  } catch (error) {
    console.error('Error setting user ID:', error);
  }
}

export async function logScreenView(screenName: string, screenClass: string) {
  try {
    await analytics().logScreenView({
      screen_name: screenName,
      screen_class: screenClass,
    });
    console.log(`Logged screen view: ${screenName}`);
  } catch (error) {
    console.error('Error logging screen view:', error);
  }
}