export function searchMessages(messages, query) {
  return messages.filter(message => 
    message.content.toLowerCase().includes(query.toLowerCase())
  );
}

export function filterMessagesByDate(messages, startDate, endDate) {
  return messages.filter(message => {
    const messageDate = new Date(message.timestamp);
    return messageDate >= startDate && messageDate <= endDate;
  });
}

export function filterMessagesBySender(messages, senderId) {
  return messages.filter(message => message.senderId === senderId);
}