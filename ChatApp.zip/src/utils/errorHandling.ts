import * as Sentry from "@sentry/react-native";

Sentry.init({
  dsn: "YOUR_SENTRY_DSN",
  // Set tracesSampleRate to 1.0 to capture 100% of transactions for performance monitoring.
  // We recommend adjusting this value in production.
  tracesSampleRate: 1.0,
});

export function logError(error: Error, context?: object) {
  console.error(error);
  Sentry.captureException(error, { extra: context });
}

export function logInfo(message: string, data?: object) {
  console.log(message, data);
  Sentry.captureMessage(message, { level: "info", extra: data });
}

export function handleApiError(error: any) {
  if (error.response) {
    // The request was made and the server responded with a status code
    // that falls out of the range of 2xx
    logError(new Error(`API Error: ${error.response.status}`), {
      data: error.response.data,
      headers: error.response.headers,
    });
  } else if (error.request) {
    // The request was made but no response was received
    logError(new Error("No response received from API"), {
      request: error.request,
    });
  } else {
    // Something happened in setting up the request that triggered an Error
    logError(error);
  }
}