import Keycloak from 'keycloak-js';

const keycloakConfig = {
  url: 'YOUR_KEYCLOAK_URL',
  realm: 'YOUR_REALM',
  clientId: 'YOUR_CLIENT_ID'
};

const keycloak = new Keycloak(keycloakConfig);

export async function initKeycloak() {
  try {
    const authenticated = await keycloak.init({ onLoad: 'check-sso' });
    if (authenticated) {
      console.log('User is authenticated');
    } else {
      console.log('User is not authenticated');
    }
    return keycloak;
  } catch (error) {
    console.error('Failed to initialize Keycloak:', error);
  }
}

export async function login() {
  try {
    await keycloak.login();
  } catch (error) {
    console.error('Login failed:', error);
  }
}

export async function logout() {
  try {
    await keycloak.logout();
  } catch (error) {
    console.error('Logout failed:', error);
  }
}

export function getToken() {
  return keycloak.token;
}

export function updateToken(minValidity = 5) {
  return keycloak.updateToken(minValidity);
}

export function hasRole(role: string) {
  return keycloak.hasRealmRole(role);
}