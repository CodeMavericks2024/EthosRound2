import AsyncStorage from '@react-native-community/async-storage';

interface QueuedMessage {
  id: string;
  recipient: string;
  content: string;
  timestamp: number;
}

export async function addToQueue(message: QueuedMessage) {
  try {
    const queue = await getQueue();
    queue.push(message);
    await AsyncStorage.setItem('messageQueue', JSON.stringify(queue));
  } catch (error) {
    console.error('Error adding message to queue:', error);
  }
}

export async function getQueue(): Promise<QueuedMessage[]> {
  try {
    const queue = await AsyncStorage.getItem('messageQueue');
    return queue ? JSON.parse(queue) : [];
  } catch (error) {
    console.error('Error getting message queue:', error);
    return [];
  }
}

export async function removeFromQueue(messageId: string) {
  try {
    const queue = await getQueue();
    const updatedQueue = queue.filter(message => message.id !== messageId);
    await AsyncStorage.setItem('messageQueue', JSON.stringify(updatedQueue));
  } catch (error) {
    console.error('Error removing message from queue:', error);
  }
}

export async function processQueue(sendMessage: (message: QueuedMessage) => Promise<boolean>) {
  const queue = await getQueue();
  for (const message of queue) {
    try {
      const sent = await sendMessage(message);
      if (sent) {
        await removeFromQueue(message.id);
      }
    } catch (error) {
      console.error('Error processing queued message:', error);
    }
  }
}