import io from 'socket.io-client';
import Peer from 'simple-peer';

const socket = io('YOUR_SIGNALING_SERVER_URL');

export function initializeWebRTC(stream: MediaStream, onStream: (stream: MediaStream) => void) {
  const peer = new Peer({
    initiator: true,
    trickle: false,
    stream: stream
  });

  peer.on('signal', (data) => {
    socket.emit('signal', JSON.stringify(data));
  });

  peer.on('stream', (remoteStream) => {
    onStream(remoteStream);
  });

  socket.on('signal', (data) => {
    peer.signal(JSON.parse(data));
  });

  return peer;
}

export function answerCall(signal: string, stream: MediaStream, onStream: (stream: MediaStream) => void) {
  const peer = new Peer({
    initiator: false,
    trickle: false,
    stream: stream
  });

  peer.on('signal', (data) => {
    socket.emit('signal', JSON.stringify(data));
  });

  peer.on('stream', (remoteStream) => {
    onStream(remoteStream);
  });

  peer.signal(JSON.parse(signal));

  return peer;
}