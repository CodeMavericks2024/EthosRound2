import CryptoJS from 'crypto-js';

const SECRET_KEY = 'your-secret-key'; // Store this securely, preferably in environment variables

export function encryptMessage(message: string): string {
  return CryptoJS.AES.encrypt(message, SECRET_KEY).toString();
}

export function decryptMessage(encryptedMessage: string): string {
  const bytes = CryptoJS.AES.decrypt(encryptedMessage, SECRET_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
}

export function generateKeyPair() {
  // Implement key pair generation for end-to-end encryption
  // This is a placeholder and should be replaced with actual implementation
  return {
    publicKey: 'public-key',
    privateKey: 'private-key'
  };
}