import validator from 'validator';
import DOMPurify from 'dompurify';

export function validateEmail(email: string): boolean {
  return validator.isEmail(email);
}

export function validatePassword(password: string): boolean {
  // At least 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special character
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return passwordRegex.test(password);
}

export function sanitizeHtml(html: string): string {
  return DOMPurify.sanitize(html);
}

export function validateUsername(username: string): boolean {
  // Alphanumeric, 3-20 characters
  const usernameRegex = /^[a-zA-Z0-9]{3,20}$/;
  return usernameRegex.test(username);
}

export function validateMessageContent(content: string): boolean {
  // Non-empty, max 1000 characters
  return content.trim().length > 0 && content.length <= 1000;
}